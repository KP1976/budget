import * as budget from './budget.fetch';
import * as common from './common.fetch';

export default {
  budget,
  common,
}